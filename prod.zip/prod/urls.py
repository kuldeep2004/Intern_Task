from django.urls import path
from . import views

urlpatterns = [
    path('api/products/', views.index, name='index'),
    path('api/<int:product_id>/', views.detail, name='detail'),
    path('products/', views.products, name='products'),
    path('products/<int:product_id>/', views.product, name='product'),
]